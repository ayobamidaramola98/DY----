#include <stdio.h>
#include <math.h>
#include <string.h> 


/*  CCESAVE(NSTEP,TIME,EPK,EIK,EEK,EKK,ETK,EEE)   */

void  ccesave_(NSTEP,TIME,EPK,EIK,EEK,EKK,ETK,EEE)

int *NSTEP;
double *TIME,*EPK,*EIK,*EEK,*EKK,*ETK,*EEE;
{

FILE *frcv ;
int i;
char FILENAME[20];

sprintf(FILENAME,"ccesave.e");

i=0;
if(( frcv = fopen(FILENAME,"r")) == NULL)
    { frcv = fopen(FILENAME,"w");
    fclose(frcv); }
else
   fclose(frcv);
 
 
frcv = fopen(FILENAME,"r+w");
 
i  = fseek(frcv, 0, SEEK_END);

fprintf(frcv,"%d  %f %f %f %f %f %f %f\n",
     *NSTEP,*TIME,*EPK,*EIK,*EEK,*EKK,*ETK,*EEE); 
fclose(frcv);

}
