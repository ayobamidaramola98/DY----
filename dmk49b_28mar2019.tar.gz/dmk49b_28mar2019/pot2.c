/*
c     $RCSfile: phoc2.c,v $
c     $Author: cdomain $
c     $Date: 1996/06/17 09:50:35 $
c     $Revision: 2.1 $
c------------------------------------------------------------
*/
/* Version STATION et CRAY */

#include <stdio.h>
#include <math.h>

#ifdef IBM
void potcc(
#else
void potcc_(
#endif
            NP, ITYPE,  NSTEP, TIME, TEMP , REALTEMP,
            VIBP, DTIME, PMASSE1, PMASSE2,
           X, Y, Z, XTR, YTR, ZTR,XBOXCM,YBOXCM, ZBOXCM ,
          EATOM, TITRE)

int *NP, *ITYPE, *NSTEP;
double *VIBP, *DTIME, *TIME, *REALTEMP, *PMASSE1, *PMASSE2 ;
double *X, *Y, *Z,*XTR, *YTR, *ZTR, *XBOXCM, *YBOXCM, *ZBOXCM;
double *EATOM ;
char *TITRE;

{
float rr, a, r;

int i, N;

double xbox, ybox, zbox;
short ix,iy,iz;
double veloc;
unsigned char CCC[6];
double dtmp;
float float_veloc;

FILE *frcv;
char FILENAME[100];

printf("In C routine : %s\n", TITRE);

for (i=0; i<=20; i++) printf("%c   ", TITRE[i]);

i = 0;
while (TITRE[i] != ' '){ FILENAME[i] = TITRE[i]; i++; }
FILENAME[i] = 0;

printf("In C routine : %s\n", FILENAME);


i=0;
if(( frcv = fopen(FILENAME,"r")) == NULL)
    { frcv = fopen(FILENAME,"w");
    fclose(frcv); }
else
   fclose(frcv);


frcv = fopen(FILENAME,"r+w");

i  = fseek(frcv, 0, SEEK_END);
printf("%d \n",i);

N = *NP;
N--;


i = sizeof(float);
dtmp = (double) i;
fwrite(&dtmp, sizeof(double), 1, frcv);

dtmp = (double) N;
fwrite(&dtmp, sizeof(double), 1, frcv);
dtmp = (double) (*NSTEP);
fwrite(&dtmp, sizeof(double), 1, frcv);
/*
fwrite(&N, sizeof(int), 1, frcv);
fwrite(NSTEP, sizeof(int), 1, frcv);
*/

fwrite(REALTEMP, sizeof(double), 1, frcv);

fwrite(VIBP, sizeof(double), 1, frcv);
fwrite(DTIME, sizeof(double), 1, frcv);

fwrite(PMASSE1, sizeof(double), 1, frcv);
fwrite(PMASSE2, sizeof(double), 1, frcv);

fwrite(XTR, sizeof(double),1,frcv);
fwrite(YTR, sizeof(double),1,frcv);
fwrite(ZTR, sizeof(double),1,frcv);

fwrite(XBOXCM, sizeof(double),1,frcv);
fwrite(YBOXCM, sizeof(double),1,frcv);
fwrite(ZBOXCM, sizeof(double),1,frcv);

xbox = 32700.0 / (*XBOXCM);
ybox = 32700.0 / (*YBOXCM);
zbox = 32700.0 / (*ZBOXCM);

for (i=0; i< N+1; i++)
{
ix = (short) ( (X[i]+(*XTR)) * xbox);
iy = (short) ( (Y[i]+(*YTR)) * ybox);
iz = (short) ( (Z[i]+(*ZTR)) * zbox);


CCC[0] = (int) ix / 256;
CCC[1] = (int) ix % 256;
CCC[2] = (int) iy / 256;
CCC[3] = (int) iy % 256;
CCC[4] = (int) iz / 256;
CCC[5] = (int) iz % 256;
/*
printf("%d %d %d  %d %d  %d %d  %d %d   %d %d\n", ix,iy,iz, CCC[0],
    CCC[1],CCC[2],CCC[3],CCC[4],CCC[5], ix % 256, iy % 256);
*/
/*
fwrite(&ix, sizeof(short), 1, frcv);
fwrite(&iy, sizeof(short), 1, frcv);
fwrite(&iz, sizeof(short), 1, frcv);
*/
fwrite(CCC, sizeof(char), 6, frcv);

veloc = EATOM[i] ;

float_veloc = (float) veloc;

fwrite(&float_veloc, sizeof(float), 1, frcv);

}

/*
printf("%g %g \n", *DTIME, *VIBP);
*/

fclose(frcv);
}


