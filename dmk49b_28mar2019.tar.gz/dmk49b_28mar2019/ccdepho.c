#include <stdio.h>
#include <math.h>
#include <string.h> 


/*  CCESAVE(NSTEP,TIME,EPK,EIK,EEK,EKK,ETK,EEE)   */

void  ccdepho_(NSTEP,TIME,Nvacancy, Ndumbell, Ndumbell1,
       Ndumbell2, Nrempla, Ninter, Nclosepair)

int *NSTEP;
double *TIME;
int *Nvacancy, *Ndumbell, *Ndumbell1, *Ndumbell2, *Nrempla, *Ninter, *Nclosepair;
{

FILE *frcv ;
int i;
char FILENAME[20];

sprintf(FILENAME,"ccdefects.depho");

i=0;
if(( frcv = fopen(FILENAME,"r")) == NULL)
    { frcv = fopen(FILENAME,"w");
    fclose(frcv); }
else
   fclose(frcv);
 
 
frcv = fopen(FILENAME,"r+w");
 
i  = fseek(frcv, 0, SEEK_END);

fprintf(frcv,"%5d  %f %5d %5d %5d %5d %5d %5d %5d\n",
     *NSTEP,*TIME,*Nvacancy, *Ndumbell, *Ndumbell1, *Ndumbell2,
       *Nrempla, *Ninter, *Nclosepair); 
fclose(frcv);

}
