
#include <stdio.h>
#include <math.h>
#include <string.h>


void ccxyz0_(TITRE)
char *TITRE;
{
FILE *frcv;
int i;
 
i = 0;
 
 
i=0;
if(( frcv = fopen(TITRE,"w")) == NULL)
    {  printf("Pb open file %s \n", TITRE);
    exit(1); }
   fclose(frcv);


}

void ccxyz1_(N1, N2, TITRE)

int *N1, *N2;
char *TITRE;

{
FILE *frcv;
int i;


frcv = fopen(TITRE,"r+w");

i  = fseek(frcv, 0, SEEK_END);

fprintf(frcv,"%d\n %d\n", *N1, *N2);

fclose(frcv);
}




void ccxyz2_(X1,X2,X3, TYP, TITRE)

double *X1, *X2, *X3;
char *TITRE, *TYP;

{

FILE *frcv;
char ATOM[100];
int i;


i = 0;
while (TYP[i] != ' '){ ATOM[i] = TYP[i]; i++; }
ATOM[i] = 0;


frcv = fopen(TITRE,"r+w");

i  = fseek(frcv, 0, SEEK_END);

fprintf(frcv,"%s  %f %f %f\n", TYP, *X1, *X2, *X3 );

fclose(frcv);
}




















